#!/bin/bash
set -e

temp_dir="$(mktemp -d)"
cleanup() {
  rm -rf "$temp_dir"
}
trap cleanup EXIT

subreddit="${1:-}"
app_name="${2:-}"

if [[ -z "$subreddit" ]]; then
  echo "Missing required subreddit argument." >&2
  echo "{\"ok\":false,\"error\":\"missing_subreddit\"}"
  exit 1
fi

args=("logs" "$subreddit")
shift || true

if [[ -n "$app_name" && "$app_name" != --* ]]; then
  args+=("$app_name")
  shift || true
fi

if [[ "$#" -gt 0 ]]; then
  args+=("$@")
fi

echo "Streaming devvit logs for ${subreddit} (auto-exit after 5s)..." >&2

node -e '
const { spawn } = require("child_process");

const args = process.argv.slice(2);
const child = spawn("devvit", args, { stdio: ["ignore", "pipe", "pipe"] });

let stdout = "";
let stderr = "";
let done = false;
let gotData = false;
let debounceTimer = null;

const hardTimeoutMs = 5000;
const debounceMs = 500;

const hardTimer = setTimeout(() => finish("timeout"), hardTimeoutMs);

function scheduleDebounce() {
  if (debounceTimer) return;
  debounceTimer = setTimeout(() => finish("debounce"), debounceMs);
}

function finish(reason) {
  if (done) return;
  done = true;
  clearTimeout(hardTimer);
  if (debounceTimer) clearTimeout(debounceTimer);

  if (!child.killed) {
    child.kill("SIGINT");
    setTimeout(() => {
      if (!child.killed) child.kill("SIGKILL");
    }, 500);
  }

  const result = {
    ok: true,
    reason,
    exitCode: child.exitCode ?? null,
    signal: child.signalCode ?? null,
    stdout: stdout.trimEnd(),
    stderr: stderr.trimEnd(),
  };

  process.stdout.write(JSON.stringify(result, null, 2));
}

child.stdout.on("data", (chunk) => {
  stdout += chunk.toString("utf8");
  if (!gotData) {
    gotData = true;
    scheduleDebounce();
  }
});

child.stderr.on("data", (chunk) => {
  stderr += chunk.toString("utf8");
});

child.on("error", (err) => {
  if (done) return;
  done = true;
  clearTimeout(hardTimer);
  if (debounceTimer) clearTimeout(debounceTimer);
  process.stdout.write(JSON.stringify({
    ok: false,
    error: err.message
  }, null, 2));
});

child.on("exit", () => {
  if (!done) finish("exit");
});
' -- "${args[@]}"
#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
node "$SCRIPT_DIR/devvit-logs.js" "$@"
